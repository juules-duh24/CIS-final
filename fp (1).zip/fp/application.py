from cs50 import SQL
from flask import Flask, render_template, redirect, request

app = Flask(__name__)
#using css library water.css for styling
#using cloudflare to style top bar
###wording from "thanks" template provided by https://codepen.io/CameronFitzwilliam/pen/pamobO


db = SQL("sqlite:///submit.db")

@app.route("/")
def index():
    return render_template("homepage.html")

@app.route("/federalPrograms")
def federal():
    return render_template("federalprograms.html")

@app.route("/food")
def food():
    return render_template("food.html")

@app.route("/bills")
def bills():
    return render_template("bills.html")


@app.route("/health")
def health():
    return render_template("health.html")

@app.route("/education")
def education():
    return render_template("education.html")

@app.route("/additional")
def additional():
    return render_template("additional.html")

@app.route("/forme")
def forme():
        rows = db.execute("SELECT * FROM submit")
        return render_template("forme.html", rows=rows)

@app.route("/submit", methods=["GET","POST"])
def submit():
        if request.method=="GET":
            return render_template("submit.html")
        else:
            name = request.form.get("name")
            email = request.form.get("email")
            suggestion = request.form.get("suggestion")
            db.execute("INSERT INTO submission (name,email,suggestion) VALUES (:name,:email,:suggestion)", name=name, email=email, suggestion=suggestion)
            return render_template("thanks.html")
